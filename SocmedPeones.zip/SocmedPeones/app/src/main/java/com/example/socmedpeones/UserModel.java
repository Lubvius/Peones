package com.example.socmedpeones;

public class UserModel {
    private String userid;
    private String userName;
    private String userEmail;
    private String userNumber;
    private String userBio;
    private String userProfile;
    private String userCover;

    public UserModel() {
        this.userid = userid;
    }

    public UserModel(String userid, String userName, String userEmail, String userNumber, String userBio, String userProfile, String userCover) {
        this.userid = userid;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userNumber = userNumber;
        this.userBio = userBio;
        this.userProfile = userProfile;
        this.userCover = userCover;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public void setUserBio(String userBio) {
        this.userBio = userBio;
    }

    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

    public void setUserCover(String userCover) {
        this.userCover = userCover;
    }

    public String getUserNumber() {
        return userNumber;
    }

    public void setUserNumber(String userNumber) {
        this.userNumber = userNumber;
    }

    public static Object getUserProfile() {
        return null;
    }

    public String getUserProfil() {
        return null;
    }

    public String getUserid() {
        return userid;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getUserBio() {
        return userBio;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserCover() {
        return userCover;
    }
}
