package com.example.socmedpeones;

public class CommentModel {
    private String userid;
    private String commentid;
    private String postid;
    private String comment;

    public CommentModel(String userid, String commentid, String postid, String comment) {
        this.userid = userid;
        this.commentid = commentid;
        this.postid = postid;
        this.comment = comment;
    }
    
    public CommentModel() {
        
    }


    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getCommentid() {
        return commentid;
    }

    public void setCommentid(String commentid) {
        this.commentid = commentid;
    }

    public String getPostid() {
        return postid;
    }

    public void setPostid(String postid) {
        this.postid = postid;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void addPost(CommentModel commentModel) {
    }
}
