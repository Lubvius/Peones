package com.example.socmedpeones;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.socmedpeones.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding binding;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.goToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,LoginActivity.class));
            }
        });

        binding.createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nama=binding.nama.getText().toString();
                String nik=binding.nik.getText().toString();
                String email=binding.email.getText().toString();
                String password=binding.password.getText().toString();

                progressDialog=new ProgressDialog(MainActivity.this);

                progressDialog.setTitle("Membuat");
                progressDialog.setMessage("Sedang Membuat harap tunggu");
                progressDialog.show();

                FirebaseAuth
                        .getInstance()
                        .createUserWithEmailAndPassword(email.trim(),password.trim())
                        .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                            @Override
                            public void onSuccess(AuthResult authResult) {
                                UserProfileChangeRequest userProfileChangeRequest=new UserProfileChangeRequest.Builder().setDisplayName(nama).build();
                                FirebaseAuth.getInstance().getCurrentUser()
                                        .updateProfile(userProfileChangeRequest);
                                new MySharedPreferences(MainActivity.this).setMyData(nik);
                                UserModel userModel=new UserModel();
                                userModel.setUserName(nama);
                                userModel.setUserNumber(nik);
                                userModel.setUserEmail(email);

                                FirebaseFirestore
                                        .getInstance()
                                        .collection("Users")
                                        .document(FirebaseAuth.getInstance().getUid())
                                        .set(userModel);
                                reset();

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                progressDialog.cancel();
                                Toast.makeText(MainActivity.this, "Membuat akun anda Gagal!! silahkan coba lagi", Toast.LENGTH_SHORT).show();
                                
                            }
                        });

            }
        });
    }

    private void reset() {
        progressDialog.cancel();
        Toast.makeText(this, "Akun sudah dibuat silahkan Login!!", Toast.LENGTH_SHORT).show();
    //    FirebaseAuth.getInstance().signOut();
    }
}